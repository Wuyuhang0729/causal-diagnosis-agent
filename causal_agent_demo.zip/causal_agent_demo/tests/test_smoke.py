from pathlib import Path
import pandas as pd

from src.causal_agent.agent import CausalDiagnosisAgent
from src.causal_agent.models import IncidentConfig


def test_analysis_smoke(tmp_path):
    metrics = pd.DataFrame([
        {"timestamp": "2026-04-30T00:00:00Z", "metric": "conversion", "value": 3.2},
        {"timestamp": "2026-04-30T00:10:00Z", "metric": "conversion", "value": 3.1},
        {"timestamp": "2026-04-30T00:20:00Z", "metric": "conversion", "value": 1.8},
        {"timestamp": "2026-04-30T00:30:00Z", "metric": "conversion", "value": 1.9},
        {"timestamp": "2026-04-30T00:00:00Z", "metric": "payment_success", "value": 98},
        {"timestamp": "2026-04-30T00:20:00Z", "metric": "payment_success", "value": 88},
    ])
    events = pd.DataFrame([
        {"timestamp": "2026-04-30T00:15:00Z", "event_type": "deploy_release", "source": "ci", "entity": "game", "severity": "high"},
        {"timestamp": "2026-04-30T00:16:00Z", "event_type": "config_change", "source": "ops", "entity": "game", "severity": "medium"},
    ])
    cfg = IncidentConfig(
        alert_time="2026-04-30T00:20:00Z",
        target_metric="conversion",
        baseline_window_minutes=30,
        incident_window_minutes=20,
    )
    agent = CausalDiagnosisAgent(memory_path=tmp_path / "mem.jsonl")
    result = agent.analyze(metrics, events, cfg)
    assert result.top_candidates
    assert result.report_markdown
