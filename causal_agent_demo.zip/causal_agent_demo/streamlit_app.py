from __future__ import annotations

from pathlib import Path
import json

import pandas as pd
import streamlit as st
import networkx as nx
import matplotlib.pyplot as plt

from src.causal_agent.agent import CausalDiagnosisAgent
from src.causal_agent.io import load_bundle
from src.causal_agent.models import IncidentConfig
from src.causal_agent.connectors import DryRunExecutor

st.set_page_config(page_title="Causal Diagnosis Agent", layout="wide")

agent = CausalDiagnosisAgent()

st.title("跨系统因果诊断与自动干预 Agent Demo")

with st.sidebar:
    st.header("输入")
    use_sample = st.checkbox("使用样例数据", value=True)
    uploaded_metrics = st.file_uploader("metrics.csv", type=["csv"])
    uploaded_events = st.file_uploader("events.csv", type=["csv"])
    uploaded_config = st.file_uploader("config.json", type=["json"])
    run_button = st.button("运行分析", type="primary")

def load_uploaded():
    metrics = pd.read_csv(uploaded_metrics)
    events = pd.read_csv(uploaded_events)
    cfg_raw = json.loads(uploaded_config.read_text(encoding="utf-8")) if uploaded_config else {}
    return metrics, events, cfg_raw

def load_sample():
    return load_bundle(Path("samples"))

def draw_graph(graph: nx.DiGraph):
    if graph.number_of_nodes() == 0:
        st.info("无图可视化")
        return
    fig = plt.figure(figsize=(10, 6))
    pos = nx.spring_layout(graph, seed=42)
    node_colors = []
    for _, attrs in graph.nodes(data=True):
        node_colors.append("#7aa6ff" if attrs.get("kind") == "metric" else "#ffb26b")
    nx.draw_networkx_nodes(graph, pos, node_size=1200, node_color=node_colors, alpha=0.9)
    nx.draw_networkx_labels(graph, pos, font_size=8)
    nx.draw_networkx_edges(graph, pos, arrows=True, arrowsize=15, width=1.2, alpha=0.6)
    edge_labels = {(u, v): d.get("relation", "") for u, v, d in graph.edges(data=True)}
    nx.draw_networkx_edge_labels(graph, pos, edge_labels=edge_labels, font_size=7)
    plt.axis("off")
    st.pyplot(fig, clear_figure=True)

if run_button:
    if use_sample or (uploaded_metrics and uploaded_events):
        if use_sample:
            metrics, events, cfg = load_sample()
        else:
            metrics, events, cfg_raw = load_uploaded()
            cfg = IncidentConfig(**cfg_raw)

        with st.spinner("分析中..."):
            result = agent.analyze(metrics, events, cfg)
            graph = None
            # rebuild graph for visualization
            from src.causal_agent.analysis import build_causal_graph
            graph = build_causal_graph(metrics, events)

        col1, col2, col3, col4 = st.columns(4)
        col1.metric("基线值", f"{result.baseline_value:.4f}")
        col2.metric("异常值", f"{result.incident_value:.4f}")
        col3.metric("变化率", f"{result.delta_pct:.2f}%")
        col4.metric("异常检测", "是" if result.anomaly_detected else "否")

        left, right = st.columns([1.15, 0.85])

        with left:
            st.subheader("根因候选")
            for idx, c in enumerate(result.top_candidates, 1):
                with st.expander(f"{idx}. {c.node} | score={c.score:.2f}", expanded=(idx == 1)):
                    st.write("原因：", c.reason)
                    st.write("证据：", ", ".join(c.evidence) if c.evidence else "无")
                    st.write("建议动作：", c.proposed_action)
                    st.write("动作类型：", c.action_type)

            st.subheader("因果路径")
            for p in result.causal_paths:
                st.code(" -> ".join(p))

            st.subheader("建议与验证")
            st.write("\n".join([f"- {x}" for x in result.recommendations + result.validation_notes]))

            st.subheader("报告")
            st.code(result.report_markdown)

        with right:
            st.subheader("因果图")
            draw_graph(graph)

            st.subheader("Dry-run 执行")
            if result.top_candidates:
                top = result.top_candidates[0]
                exe = DryRunExecutor()
                exec_result = exe.execute(top.action_type, {"node": top.node, "score": top.score, "target_metric": cfg.target_metric})
                st.json(exec_result.__dict__)

            st.subheader("记忆库")
            memory = agent.load_memory(limit=10)
            st.json(memory)
    else:
        st.warning("请上传 metrics.csv 和 events.csv，或勾选使用样例数据。")
