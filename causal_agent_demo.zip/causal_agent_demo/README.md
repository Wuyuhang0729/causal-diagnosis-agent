# Causal Diagnosis & Auto-Intervention Agent Demo

A GitHub-ready demo project for a multi-source causal diagnosis agent with automated intervention planning.

## What it does

- Ingests metrics, event logs, and version/config changes
- Detects anomalies in a target metric
- Builds a lightweight causal graph
- Ranks likely root causes with differential attribution + causal scoring
- Recommends a lowest-risk intervention
- Executes in dry-run mode and writes an incident report
- Stores incident memory for later reuse

## Run locally

### Streamlit UI
```bash
pip install -r requirements.txt
streamlit run streamlit_app.py
```

### FastAPI backend
```bash
uvicorn api:app --reload --port 8000
```

## Files

- `streamlit_app.py` — UI demo
- `api.py` — REST API
- `src/causal_agent/` — core agent logic
- `samples/` — sample incident data
- `tests/` — basic tests

## Input format

### metrics.csv
Columns:
- `timestamp`
- `metric`
- `value`
- optional dimensions like `service`, `region`, `version`

### events.csv
Columns:
- `timestamp`
- `event_type`
- `source`
- `entity`
- `severity`
- optional `payload`

### config.json
Optional metadata:
- `alert_time`
- `target_metric`
- `service`
- `baseline_window_minutes`
- `incident_window_minutes`

## Notes

This project uses a conservative, explainable scoring pipeline. It is intentionally designed as a dry-run agent:
- it does not execute destructive actions
- it produces rollback/adjustment recommendations that can be wired to real systems later
