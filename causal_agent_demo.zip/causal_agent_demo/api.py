from __future__ import annotations

from fastapi import FastAPI
from pydantic import BaseModel, Field
import pandas as pd

from src.causal_agent.agent import CausalDiagnosisAgent
from src.causal_agent.models import IncidentConfig

app = FastAPI(title="Causal Diagnosis Agent", version="1.0.0")
agent = CausalDiagnosisAgent()


class AnalyzeRequest(BaseModel):
    metrics: list[dict] = Field(default_factory=list)
    events: list[dict] = Field(default_factory=list)
    config: dict


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/analyze")
def analyze(req: AnalyzeRequest):
    metrics = pd.DataFrame(req.metrics)
    events = pd.DataFrame(req.events)
    cfg = IncidentConfig(**req.config)
    result = agent.analyze(metrics, events, cfg)
    return result.to_dict()


@app.post("/execute")
def execute(req: AnalyzeRequest):
    metrics = pd.DataFrame(req.metrics)
    events = pd.DataFrame(req.events)
    cfg = IncidentConfig(**req.config)
    result = agent.analyze(metrics, events, cfg)
    top = result.top_candidates[0] if result.top_candidates else None
    if top is None:
        return {"ok": False, "message": "No candidate found", "analysis": result.to_dict()}
    from src.causal_agent.connectors import DryRunExecutor
    exe = DryRunExecutor()
    exec_result = exe.execute(top.action_type, {"node": top.node, "score": top.score, "target_metric": cfg.target_metric})
    return {"ok": exec_result.ok, "execution": exec_result.__dict__, "analysis": result.to_dict()}
