from __future__ import annotations

import json
from dataclasses import asdict, is_dataclass
from pathlib import Path
from typing import Any, Iterable, List

import pandas as pd


def ensure_datetime(df: pd.DataFrame, column: str = "timestamp") -> pd.DataFrame:
    if column in df.columns:
        df = df.copy()
        df[column] = pd.to_datetime(df[column], utc=True, errors="coerce")
        df = df[df[column].notna()]
    return df


def load_json_file(path: str | Path) -> Any:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def save_json_file(path: str | Path, obj: Any) -> None:
    def default(o):
        if is_dataclass(o):
            return asdict(o)
        if hasattr(o, "tolist"):
            return o.tolist()
        raise TypeError(f"Object of type {type(o).__name__} is not JSON serializable")

    Path(path).write_text(json.dumps(obj, ensure_ascii=False, indent=2, default=default), encoding="utf-8")


def sliding_window_mean(series: pd.Series, start, end) -> float:
    window = series.loc[(series.index >= start) & (series.index < end)]
    if window.empty:
        return float("nan")
    return float(window.mean())


def top_n(items: Iterable[Any], n: int) -> List[Any]:
    return list(items)[:n]
