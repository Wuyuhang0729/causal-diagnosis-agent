from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional


@dataclass
class MetricRecord:
    timestamp: str
    metric: str
    value: float
    service: str = "unknown"
    region: str = "global"
    version: str = "unknown"
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class EventRecord:
    timestamp: str
    event_type: str
    source: str = "unknown"
    entity: str = "unknown"
    severity: str = "info"
    payload: Dict[str, Any] = field(default_factory=dict)


@dataclass
class IncidentConfig:
    alert_time: str
    target_metric: str
    service: str = "unknown"
    baseline_window_minutes: int = 60
    incident_window_minutes: int = 30
    memory_namespace: str = "default"


@dataclass
class RootCauseCandidate:
    node: str
    score: float
    reason: str
    evidence: List[str] = field(default_factory=list)
    proposed_action: str = "none"
    action_type: str = "observe"


@dataclass
class AnalysisResult:
    alert_time: str
    target_metric: str
    baseline_value: float
    incident_value: float
    delta_pct: float
    anomaly_detected: bool
    top_candidates: List[RootCauseCandidate]
    causal_paths: List[List[str]]
    recommendations: List[str]
    validation_notes: List[str]
    report_markdown: str

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)
