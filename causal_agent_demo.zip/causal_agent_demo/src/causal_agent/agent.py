from __future__ import annotations

from dataclasses import asdict
from pathlib import Path
from typing import Dict, Optional, Tuple
import json

import networkx as nx
import pandas as pd

from .analysis import build_causal_graph, compute_metric_shift, infer_causal_paths, rank_root_causes
from .data import infer_dimensions
from .models import AnalysisResult, IncidentConfig, RootCauseCandidate
from .report import render_report
from .validation import self_evaluate, simulate_intervention


class CausalDiagnosisAgent:
    def __init__(self, memory_path: str | Path = "memory/incidents.jsonl"):
        self.memory_path = Path(memory_path)
        self.memory_path.parent.mkdir(parents=True, exist_ok=True)

    def analyze(self, metrics: pd.DataFrame, events: pd.DataFrame, config: IncidentConfig) -> AnalysisResult:
        metrics = metrics.copy()
        events = events.copy()

        metrics["timestamp"] = pd.to_datetime(metrics["timestamp"], utc=True, errors="coerce")
        events["timestamp"] = pd.to_datetime(events["timestamp"], utc=True, errors="coerce")
        metrics = metrics[metrics["timestamp"].notna()].sort_values("timestamp")
        events = events[events["timestamp"].notna()].sort_values("timestamp")

        alert_time = pd.Timestamp(config.alert_time, tz="UTC")
        shift = compute_metric_shift(metrics, config.target_metric, alert_time, config.baseline_window_minutes, config.incident_window_minutes)

        graph = build_causal_graph(metrics, events)
        top_candidates = rank_root_causes(metrics, events, config.target_metric, alert_time, config.baseline_window_minutes, config.incident_window_minutes)
        paths = infer_causal_paths(graph, top_candidates, config.target_metric)
        notes = self_evaluate(top_candidates)

        recommendations = []
        if top_candidates:
            top = top_candidates[0]
            recommendations.append(f"优先处理 {top.node}：{top.proposed_action}")
            if top.action_type != "observe":
                recommendations.append(f"建议执行干预：{top.action_type}")
            validation = simulate_intervention(config.target_metric, top)
            notes.append(validation["prediction"])
        else:
            recommendations.append("证据不足，建议扩大时间窗口并补充日志维度")

        report = render_report(
            config=config,
            shift=shift,
            top_candidates=top_candidates,
            paths=paths,
            recommendations=recommendations,
            validation_notes=notes,
            graph=graph,
        )

        self._append_memory(config, metrics, events, top_candidates, shift, report)

        return AnalysisResult(
            alert_time=config.alert_time,
            target_metric=config.target_metric,
            baseline_value=shift["baseline_value"],
            incident_value=shift["incident_value"],
            delta_pct=shift["delta_pct"],
            anomaly_detected=abs(shift["delta_pct"]) >= 5.0,
            top_candidates=top_candidates,
            causal_paths=paths,
            recommendations=recommendations,
            validation_notes=notes,
            report_markdown=report,
        )

    def _append_memory(self, config: IncidentConfig, metrics: pd.DataFrame, events: pd.DataFrame, candidates, shift, report: str) -> None:
        record = {
            "alert_time": config.alert_time,
            "target_metric": config.target_metric,
            "service": config.service,
            "baseline_value": shift["baseline_value"],
            "incident_value": shift["incident_value"],
            "delta_pct": shift["delta_pct"],
            "top_candidates": [
                {
                    "node": c.node,
                    "score": c.score,
                    "reason": c.reason,
                    "action_type": c.action_type,
                    "proposed_action": c.proposed_action,
                } for c in candidates[:3]
            ],
            "dimensions": infer_dimensions(metrics),
        }
        with self.memory_path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")

    def load_memory(self, limit: int = 20):
        if not self.memory_path.exists():
            return []
        lines = self.memory_path.read_text(encoding="utf-8").splitlines()
        records = []
        for line in lines[-limit:]:
            try:
                records.append(json.loads(line))
            except json.JSONDecodeError:
                continue
        return records
