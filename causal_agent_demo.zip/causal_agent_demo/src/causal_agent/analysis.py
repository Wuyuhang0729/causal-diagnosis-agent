from __future__ import annotations

from dataclasses import asdict
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd
import networkx as nx

from .models import RootCauseCandidate


def _safe_mean(series: pd.Series) -> float:
    if series is None or series.empty:
        return float("nan")
    return float(series.mean())


def compute_metric_shift(metrics: pd.DataFrame, target_metric: str, alert_time: pd.Timestamp, baseline_minutes: int, incident_minutes: int) -> Dict[str, float]:
    m = metrics[metrics["metric"] == target_metric].copy()
    if m.empty:
        raise ValueError(f"Target metric '{target_metric}' not found")
    m = m.sort_values("timestamp").set_index("timestamp")
    baseline_start = alert_time - pd.Timedelta(minutes=baseline_minutes)
    incident_end = alert_time + pd.Timedelta(minutes=incident_minutes)
    baseline = m.loc[(m.index >= baseline_start) & (m.index < alert_time), "value"]
    incident = m.loc[(m.index >= alert_time) & (m.index <= incident_end), "value"]
    baseline_value = _safe_mean(baseline)
    incident_value = _safe_mean(incident)
    if np.isnan(baseline_value) or baseline_value == 0:
        delta_pct = 0.0
    else:
        delta_pct = (incident_value - baseline_value) / abs(baseline_value) * 100.0
    return {
        "baseline_value": baseline_value,
        "incident_value": incident_value,
        "delta_pct": float(delta_pct),
    }


def build_causal_graph(metrics: pd.DataFrame, events: pd.DataFrame) -> nx.DiGraph:
    g = nx.DiGraph()

    metric_nodes = sorted(metrics["metric"].dropna().unique().tolist()) if not metrics.empty else []
    event_nodes = sorted(events["event_type"].dropna().unique().tolist()) if not events.empty else []

    for node in metric_nodes:
        g.add_node(f"metric:{node}", kind="metric")
    for node in event_nodes:
        g.add_node(f"event:{node}", kind="event")

    # Temporal / structural heuristics
    for e in event_nodes:
        for m in metric_nodes:
            g.add_edge(f"event:{e}", f"metric:{m}", relation="candidate_influence")

    # Co-change edges from lagged correlations
    if not metrics.empty:
        wide = metrics.pivot_table(index="timestamp", columns="metric", values="value", aggfunc="mean").sort_index().ffill()
        if len(wide.columns) >= 2 and len(wide) >= 3:
            corr = wide.corr().fillna(0.0)
            cols = corr.columns.tolist()
            for i, a in enumerate(cols):
                for b in cols[i + 1:]:
                    score = float(abs(corr.loc[a, b]))
                    if score >= 0.35:
                        g.add_edge(f"metric:{a}", f"metric:{b}", relation="correlated", weight=score)
                        g.add_edge(f"metric:{b}", f"metric:{a}", relation="correlated", weight=score)

    return g


def rank_root_causes(metrics: pd.DataFrame, events: pd.DataFrame, target_metric: str, alert_time: pd.Timestamp, baseline_minutes: int, incident_minutes: int) -> List[RootCauseCandidate]:
    if metrics.empty:
        return []

    target = metrics[metrics["metric"] == target_metric].copy()
    if target.empty:
        raise ValueError(f"Target metric '{target_metric}' not found")

    baseline_start = alert_time - pd.Timedelta(minutes=baseline_minutes)
    incident_end = alert_time + pd.Timedelta(minutes=incident_minutes)

    candidates: List[RootCauseCandidate] = []

    # Metric candidates
    metric_names = sorted(metrics["metric"].dropna().unique())
    for metric_name in metric_names:
        series = metrics[metrics["metric"] == metric_name].copy()
        series = series.sort_values("timestamp").set_index("timestamp")["value"]
        baseline = series.loc[(series.index >= baseline_start) & (series.index < alert_time)]
        incident = series.loc[(series.index >= alert_time) & (series.index <= incident_end)]
        if baseline.empty or incident.empty:
            continue

        base = float(baseline.mean())
        inc = float(incident.mean())
        if np.isnan(base) or np.isnan(inc):
            continue

        if base == 0:
            shift = abs(inc - base)
            rel = min(1.0, shift / (abs(inc) + 1.0))
        else:
            rel = min(1.0, abs((inc - base) / abs(base)))

        # Support directionality: negative on target is stronger for outage-like issues
        target_shift = compute_metric_shift(metrics, target_metric, alert_time, baseline_minutes, incident_minutes)["delta_pct"]
        direction_boost = 1.0
        if metric_name == target_metric:
            direction_boost = 1.4
        elif abs(target_shift) > 5 and abs(inc - base) > 0:
            direction_boost = 1.15

        score = float((0.45 * rel + 0.25 * min(1.0, abs(target_shift) / 30.0) + 0.30 * direction_boost) * 100.0)
        reason = f"窗口内均值变化 {base:.3f} → {inc:.3f}，相对变化 {rel*100:.1f}%"
        evidence = [f"baseline={base:.4f}", f"incident={inc:.4f}", f"relative_change={rel:.3f}"]
        proposed_action, action_type = _propose_action(metric_name, score, target_metric)
        candidates.append(RootCauseCandidate(
            node=f"metric:{metric_name}",
            score=score,
            reason=reason,
            evidence=evidence,
            proposed_action=proposed_action,
            action_type=action_type,
        ))

    # Event candidates
    if not events.empty:
        window_events = events[(events["timestamp"] >= baseline_start) & (events["timestamp"] <= incident_end)].copy()
        event_counts = window_events.groupby("event_type").size().to_dict()
        for event_type, count in event_counts.items():
            severity_boost = 1.0
            if any(s in event_type.lower() for s in ["deploy", "release", "config", "rollback", "payment", "reward"]):
                severity_boost = 1.2
            score = float(min(100.0, 35.0 + count * 12.0 * severity_boost))
            reason = f"异常窗口内出现 {count} 次事件，事件类型与版本/配置变更相关"
            evidence = [f"count={count}", f"window='[{baseline_start.isoformat()}, {incident_end.isoformat()}]'"]
            proposed_action, action_type = _propose_event_action(event_type)
            candidates.append(RootCauseCandidate(
                node=f"event:{event_type}",
                score=score,
                reason=reason,
                evidence=evidence,
                proposed_action=proposed_action,
                action_type=action_type,
            ))

    candidates.sort(key=lambda x: x.score, reverse=True)
    # Deduplicate by node
    seen = set()
    unique = []
    for c in candidates:
        if c.node in seen:
            continue
        unique.append(c)
        seen.add(c.node)
    return unique[:5]


def _propose_action(metric_name: str, score: float, target_metric: str) -> Tuple[str, str]:
    lname = metric_name.lower()
    tname = target_metric.lower()
    if metric_name == target_metric:
        return ("回滚与复核目标指标配置，触发工单并通知值班", "rollback")
    if any(k in lname for k in ["error", "fail", "crash", "timeout"]):
        return ("切换到备用通道或回滚最近发布，生成工单", "rollback")
    if any(k in lname for k in ["conversion", "pay", "revenue", "retention"]):
        return ("检查活动/概率/价格规则，必要时进行灰度调整", "adjustment")
    if any(k in lname for k in ["latency", "frame", "perf", "cpu", "memory"]):
        return ("降低负载或关闭高成本特效/功能，提交告警工单", "throttle")
    return ("记录观察并持续采样，必要时人工确认", "observe")


def _propose_event_action(event_type: str) -> Tuple[str, str]:
    lname = event_type.lower()
    if "deploy" in lname or "release" in lname:
        return ("对最近发布进行灰度回退或增量暂停", "rollback")
    if "config" in lname or "rule" in lname:
        return ("回退配置版本并生成变更工单", "rollback")
    if "payment" in lname:
        return ("切换支付通道并发起人工复核工单", "redirect")
    if "reward" in lname or "gacha" in lname:
        return ("锁定活动规则并检查奖励发放链路", "adjustment")
    return ("记录并联动工单系统追踪", "observe")


def infer_causal_paths(graph: nx.DiGraph, top_candidates: List[RootCauseCandidate], target_metric: str) -> List[List[str]]:
    paths: List[List[str]] = []
    target_node = f"metric:{target_metric}"
    if target_node not in graph:
        return paths

    for candidate in top_candidates:
        node = candidate.node
        try:
            if nx.has_path(graph, node, target_node):
                path = nx.shortest_path(graph, node, target_node)
            elif nx.has_path(graph, target_node, node):
                path = list(reversed(nx.shortest_path(graph, target_node, node)))
            else:
                path = [node, target_node]
        except nx.NetworkXNoPath:
            path = [node, target_node]
        if path not in paths:
            paths.append(path)
    return paths


def format_graph_nodes(graph: nx.DiGraph) -> List[Dict[str, str]]:
    items = []
    for node, attrs in graph.nodes(data=True):
        items.append({"id": node, "kind": attrs.get("kind", "unknown")})
    return items
