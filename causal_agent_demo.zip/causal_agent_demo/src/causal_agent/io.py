from __future__ import annotations

from pathlib import Path
from typing import Tuple, Dict, Optional

import json
import pandas as pd

from .data import load_metrics_csv, load_events_csv, load_config_json
from .models import IncidentConfig


def load_bundle(folder: str | Path) -> Tuple[pd.DataFrame, pd.DataFrame, IncidentConfig]:
    folder = Path(folder)
    metrics = load_metrics_csv(folder / "metrics.csv")
    events = load_events_csv(folder / "events.csv")
    config_path = folder / "config.json"
    if config_path.exists():
        raw = load_config_json(config_path)
    else:
        raw = {}

    alert_time = raw.get("alert_time")
    if not alert_time:
        alert_time = str(pd.to_datetime(metrics["timestamp"]).sort_values().iloc[len(metrics)//2].isoformat())

    target_metric = raw.get("target_metric")
    if not target_metric:
        target_metric = metrics["metric"].dropna().iloc[0]

    cfg = IncidentConfig(
        alert_time=alert_time,
        target_metric=target_metric,
        service=raw.get("service", "unknown"),
        baseline_window_minutes=int(raw.get("baseline_window_minutes", 60)),
        incident_window_minutes=int(raw.get("incident_window_minutes", 30)),
        memory_namespace=raw.get("memory_namespace", "default"),
    )
    return metrics, events, cfg
