from __future__ import annotations

from typing import Dict, List

from .models import RootCauseCandidate


def simulate_intervention(target_metric: str, candidate: RootCauseCandidate) -> Dict[str, str]:
    # Deterministic dry-run validation that can be replaced by a real simulator.
    if candidate.action_type == "rollback":
        result = "预计可在短时间内回落异常指标，并缩小影响范围"
    elif candidate.action_type == "adjustment":
        result = "预计可缓解异常，但需要继续观察二次波动"
    elif candidate.action_type == "throttle":
        result = "预计能压制资源压力，降低错误扩散风险"
    elif candidate.action_type == "redirect":
        result = "预计能绕开故障链路并恢复关键转化"
    else:
        result = "预计仅能收集更多证据，不建议立即干预"
    return {
        "target_metric": target_metric,
        "candidate": candidate.node,
        "action_type": candidate.action_type,
        "prediction": result,
    }


def self_evaluate(top_candidates: List[RootCauseCandidate]) -> List[str]:
    notes = []
    if not top_candidates:
        notes.append("没有足够证据，建议扩展观察窗口或补充日志维度")
        return notes

    if top_candidates[0].score >= 70:
        notes.append("最高置信候选足以触发自动干预或人工确认")
    else:
        notes.append("当前证据偏弱，建议先生成工单并等待更多观测")
    if len(top_candidates) > 1:
        notes.append("已保留次优候选用于重规划和回退")
    return notes
