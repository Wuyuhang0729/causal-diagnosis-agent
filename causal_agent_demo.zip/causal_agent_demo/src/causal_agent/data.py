from __future__ import annotations

from pathlib import Path
from typing import Dict, Tuple, Optional

import pandas as pd

from .utils import ensure_datetime


def load_metrics_csv(path: str | Path) -> pd.DataFrame:
    df = pd.read_csv(path)
    if "timestamp" not in df.columns or "metric" not in df.columns or "value" not in df.columns:
        raise ValueError("metrics.csv must contain timestamp, metric, value columns")
    df = ensure_datetime(df, "timestamp")
    if "service" not in df.columns:
        df["service"] = "unknown"
    if "region" not in df.columns:
        df["region"] = "global"
    if "version" not in df.columns:
        df["version"] = "unknown"
    return df


def load_events_csv(path: str | Path) -> pd.DataFrame:
    df = pd.read_csv(path)
    if "timestamp" not in df.columns or "event_type" not in df.columns:
        raise ValueError("events.csv must contain timestamp, event_type columns")
    df = ensure_datetime(df, "timestamp")
    if "source" not in df.columns:
        df["source"] = "unknown"
    if "entity" not in df.columns:
        df["entity"] = "unknown"
    if "severity" not in df.columns:
        df["severity"] = "info"
    if "payload" not in df.columns:
        df["payload"] = "{}"
    return df


def load_config_json(path: str | Path) -> Dict:
    import json
    return json.loads(Path(path).read_text(encoding="utf-8"))


def infer_dimensions(metrics: pd.DataFrame) -> Dict[str, str]:
    result = {}
    for col in ["service", "region", "version"]:
        if col in metrics.columns and not metrics[col].dropna().empty:
            result[col] = str(metrics[col].dropna().mode().iloc[0])
    return result
