from __future__ import annotations

from typing import Dict, List

import networkx as nx

from .models import IncidentConfig, RootCauseCandidate


def render_report(config: IncidentConfig, shift: Dict[str, float], top_candidates: List[RootCauseCandidate], paths: List[List[str]], recommendations: List[str], validation_notes: List[str], graph: nx.DiGraph) -> str:
    lines = []
    lines.append(f"# Incident Report")
    lines.append("")
    lines.append(f"- Alert time: `{config.alert_time}`")
    lines.append(f"- Target metric: `{config.target_metric}`")
    lines.append(f"- Baseline value: `{shift['baseline_value']:.4f}`")
    lines.append(f"- Incident value: `{shift['incident_value']:.4f}`")
    lines.append(f"- Delta: `{shift['delta_pct']:.2f}%`")
    lines.append("")
    lines.append("## Top Candidates")
    if top_candidates:
        for idx, c in enumerate(top_candidates, 1):
            lines.append(f"{idx}. **{c.node}** — score `{c.score:.2f}`")
            lines.append(f"   - Reason: {c.reason}")
            if c.evidence:
                lines.append(f"   - Evidence: {', '.join(c.evidence)}")
            lines.append(f"   - Proposed action: {c.proposed_action} ({c.action_type})")
    else:
        lines.append("No candidate found.")
    lines.append("")
    lines.append("## Causal Paths")
    for p in paths:
        lines.append(f"- {' -> '.join(p)}")
    lines.append("")
    lines.append("## Recommendations")
    for r in recommendations:
        lines.append(f"- {r}")
    lines.append("")
    lines.append("## Validation Notes")
    for n in validation_notes:
        lines.append(f"- {n}")
    lines.append("")
    lines.append("## Graph Summary")
    lines.append(f"- Nodes: {graph.number_of_nodes()}")
    lines.append(f"- Edges: {graph.number_of_edges()}")
    return "\n".join(lines)
