from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Any
import uuid
import time


@dataclass
class ExecutionResult:
    ok: bool
    action: str
    reference_id: str
    message: str
    details: Dict[str, Any]


class DryRunExecutor:
    def execute(self, action_type: str, payload: Dict[str, Any]) -> ExecutionResult:
        rid = str(uuid.uuid4())[:8]
        if action_type == "rollback":
            msg = "Dry-run rollback prepared. No production changes were made."
        elif action_type == "adjustment":
            msg = "Dry-run adjustment prepared. Waiting for approval."
        elif action_type == "throttle":
            msg = "Dry-run throttling prepared. Rate-limit policy drafted."
        elif action_type == "redirect":
            msg = "Dry-run redirection prepared. Ticket created."
        else:
            msg = "Dry-run observation recorded."
        return ExecutionResult(
            ok=True,
            action=action_type,
            reference_id=rid,
            message=msg,
            details=payload,
        )
